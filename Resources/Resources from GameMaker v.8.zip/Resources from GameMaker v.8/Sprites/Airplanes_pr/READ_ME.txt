All these sprites are now free to use for anyone.
Credits to the author in your game would be nice but is not required.
Please realize that I don't have time to make sprites on demands.
I hope you will enjoy these and don't be shy to email me if you made
a game with these sprites so I can enjoy them in someone else's game.

primalmania@hotmail.com
______________________________________________________________________

IMPORTANT: Some sprite might seem weird when look in a browser like
explorer or navigator. But in game maker, all these sprites are 
supposed to look ok.
______________________________________________________________________
______________________________________________________________________